/**
 * Classes for the model of the Scotland Yard game
 */
package uk.ac.bris.cs.scotlandyard.model;